# coding=utf-8
# 代码文件：chapter8/ch8.3.1.py

for item in range(10):
    if item == 3:
        # 跳出循环
        break
    print("Count is : {0}".format(item))
