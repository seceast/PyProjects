# coding=utf-8
# 代码文件：chapter8/ch8.2.1.py

i = 0

while i * i < 100_000:
    i += 1

print("i = {0}".format(i))
print("i * i = {0}".format(i * i))