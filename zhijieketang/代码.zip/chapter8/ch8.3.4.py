# coding=utf-8
# 代码文件：chapter8/ch8.3.4.py

for item in range(1, 10, 2):
    print("Count is : {0}".format(item))

print('--------------')

for item in range(0, -10, -3):
    print("Count is : {0}".format(item))
