# coding=utf-8
# 代码文件：chapter11/ch11.3.2.py


class Animal(object):
    # 类体
    pass


animal = Animal()
print(animal)
