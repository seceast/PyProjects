# coding=utf-8
# 代码文件：chapter7/7.6/ch7.6.2.py

string_a = 'Hello'
print('e' in string_a)  # True
print('ell' not in string_a)  # False

list_a = [1, 2]
print(2 in list_a)  # True
print(1 not in list_a)  # False
