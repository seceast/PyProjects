'''
Created on 2018年1月18日
作者: 关东升
'''

string = "Hello, World."
print(string)