
string = "Hello, World."
print(string)
