# 代码文件：chapter4/4.2/hello.py

_hello = "HelloWorld"
score_for_student = 0.0
y = 20
y = True
