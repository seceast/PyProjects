# coding=utf-8

# 代码文件：chapter4/4.3/hello.py

# _hello = "HelloWorld"
# score_for_student = 0.0
y = 20
y = "大家好"

print(y)  # 打印y变量
