# coding=utf-8
#  代码文件：chapter4/4.5/module1.py

y = True
z = 10.10

print('进入module1模块')
