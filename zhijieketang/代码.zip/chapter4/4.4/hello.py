# coding=utf-8
# 代码文件：chapter4/4.4/hello.py

_hello = "HelloWorld"
score_for_student = 10.0;  # 没有错误发生
y = 20

name1 = "Tom"; name2 = "Tony"

# 链式赋值语句
a = b = c = 10

if y > 10:
    print(y)
    print(score_for_student)
else:
    print(y * 10)
print(_hello)  