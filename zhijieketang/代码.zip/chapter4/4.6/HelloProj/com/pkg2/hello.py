# coding=utf-8
# 代码文件：chapter4/4.5/com/pkg2/hello.py

y = True
z = 10.10

print('进入com.pkg2.hello模块')
