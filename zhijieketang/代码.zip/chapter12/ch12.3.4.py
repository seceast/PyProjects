# coding=utf-8
# 代码文件：chapter12/ch12.3.4.py


dict1 = {102: '张三', 105: '李四', 109: '王五'}

print(dict1[104])
