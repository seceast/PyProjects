# coding=utf-8
# 代码文件：chapter12/ch12.1.py

i = input('请输入数字：')
print(i)
print(5 / int(i))
