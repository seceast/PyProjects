# coding=utf-8
# 代码文件：chapter12/ch12.3.1.py


class Animal(object):
    pass


a1 = Animal()
# a1.run()
# print(a1.age)
# print(Animal.weight)

