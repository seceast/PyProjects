# coding=utf-8
# 代码文件：chapter12/ch12.3.2.py


f = open('abc.txt')