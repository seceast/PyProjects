# coding=utf-8
# 代码文件：chapter12/ch12.3.3.py


code_list = [125, 56, 89, 36]

print(code_list[4])

ch12.3.3.py